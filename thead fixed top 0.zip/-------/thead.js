const myDiv = document.getElementsByClassName('myDiv');
const sample = document.getElementsByClassName('sample');
let nowScTop = 0;
let thisThead, thisThead_top;
for(let divs of myDiv){
    divs.addEventListener('scroll',function(){
        nowScTop = this.scrollTop;
        thisThead = this.getElementsByTagName('THEAD')[0];
        thisThead_top = thisThead.offsetTop;
        if(nowScTop == 0){
            thisThead.style.top = 0;
        }else{
            thisThead_top = nowScTop;
            thisThead.style.top = `${thisThead_top}px`;
        }
    });
}//for
