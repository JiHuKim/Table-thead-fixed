const myDiv = document.getElementsByClassName('myDiv');
const sample = document.getElementsByClassName('sample');
let nowScTop = 0;
let asThead, asThead_top;
for(let divs of myDiv){
    divs.addEventListener('scroll',function(){
        nowScTop = this.scrollTop;
        asThead = this.getElementsByClassName('asThead')[0];
        asThead_top = asThead.offsetTop;
        if(nowScTop == 0){
            asThead.classList.remove('on');
            asThead_top.style.top = 0;
        }else{
            asThead_top = this.scrollTop;
            console.log(asThead_top);
            asThead.classList.add('on');}
            asThead.style.top = `${asThead_top}px`;
    });
}//for