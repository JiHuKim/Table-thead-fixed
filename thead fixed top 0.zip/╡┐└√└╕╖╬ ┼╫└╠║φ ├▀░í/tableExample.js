const makeFixed = document.getElementsByClassName('makeFixed');
let makeTable;
let thisColG, thisThead;

/* 동적으로 테이블 추가 */
for(let tbl of makeFixed){
    makeTable = document.createElement('TABLE');
    makeTable.setAttribute('class','fixed');
    thisColG = tbl.getElementsByTagName('COLGROUP')[0].cloneNode(true);
    thisThead = tbl.getElementsByTagName('THEAD')[0].cloneNode(true);
    makeTable.appendChild(thisColG);
    makeTable.appendChild(thisThead);
    tbl.parentElement.appendChild(makeTable);
}

/* 스크롤시 fixed 테이블은 상단에 계속 고정됨 */
const myDiv = document.getElementsByClassName('myDiv');
let thisFixed, nowScTop;
for(divs of myDiv){divs.addEventListener('scroll',theadFixed)}//

function theadFixed(){
    thisFixed = this.getElementsByClassName('fixed')[0];
    nowScTop = this.scrollTop;
    thisFixed.style.top = `${nowScTop}px`;
}//theadFixed