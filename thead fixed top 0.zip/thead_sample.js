const myDiv = document.getElementsByClassName('myDiv');
const sample = document.getElementsByClassName('sample');
let nowScTop = 0;
let asThead, asThead_top;

for(let divs of myDiv){
    divs.addEventListener('scroll',function(){
        nowScTop = this.scrollTop;
        asThead = this.getElementsByClassName('asThead')[0];
        if(nowScTop == 0){
            asThead.classList.remove('on');
            asThead.style.top = 0;
        }else{
            asThead.classList.add('on');}
            asThead.style.top = `${nowScTop}px`;
    });
}//for


/* ----------------------- */
let myThead;



myThead = myDiv[0].getElementsByClassName('sample')[0].getElementsByTagName('THEAD')[0].children;

function makeThead(data){

}//